package com.example.asif

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
