
## Flutter Widget Of The week

I have created this playkist on youtube to teach you everyday a new widget a bit more in details with practical exmaples.

- [Tutorials: Youtube](https://youtube.com/playlist?list=PLFyjjoCMAPtyjgH1Y2vBt4GlAd9FZ5xeh)

## Flutter Bootcamp 2022

- [Playlist: Youtube](https://youtube.com/playlist?list=PLFyjjoCMAPtxq8V9fuVmgsYKLNIKqSEV4)
- [RoadMap: Docs File ](https://lnkd.in/dHF8yc68)
